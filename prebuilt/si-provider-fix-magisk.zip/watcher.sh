#!/system/bin/sh
# Event-driven watcher for Storage Isolation's configuration.
#
# inotifyd blocks on the directory and runs a program for every matching event, so there is no
# idle polling: the CPU only wakes up when Storage Isolation actually writes its configuration.
#
# The directory is watched rather than the file because a save that replaces the file (write
# temp + rename) would make a file watch die with a DELETE event.
#
# inotifyd mask letters (toybox): a c e w r D M u n d m y
#   c = content modified, e = metadata, w = closed-after-write, n/m/d = create/move/delete
# The mask must be written as one token ("cwenmd"); comma-separated lists are rejected.

MODDIR=${0%/*}
LOG=/data/local/tmp/si-provider-fix.log
CONFIG_DIR=/data/adb/storage-isolation
CONFIG_NAME=configuration.json
INOTIFY_PIDFILE=/data/local/tmp/si-provider-fix.inotifyd.pid

log() {
    echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"
    lines=$(wc -l < "$LOG" 2>/dev/null || echo 0)
    if [ "$lines" -gt 400 ]; then
        tail -n 200 "$LOG" > "$LOG.tmp" 2>/dev/null && mv -f "$LOG.tmp" "$LOG"
    fi
}

# inotifyd invokes: PROG EVENTS FILE [DIRFILE]
# Reached through a tiny trampoline so that only configuration.json events trigger a push.
TRAMPOLINE=/data/local/tmp/si-provider-fix.trigger
cat > "$TRAMPOLINE" <<'EOF'
#!/system/bin/sh
# $1 = event letters, $2 = watched path, $3 = filename (when watching a directory)
MODDIR=/data/adb/modules/si-provider-fix
case "$3" in
    configuration.json|"") ;;
    *) exit 0 ;;
esac
case "$1" in
    *c*|*w*|*e*|*m*|*n*)
        sh "$MODDIR/push_rules.sh" >/dev/null 2>&1
        ;;
esac
exit 0
EOF
chmod 755 "$TRAMPOLINE"

log "watcher start pid=$$"

# initial push so rules are valid even before the first edit
sh "$MODDIR/push_rules.sh" >> "$LOG" 2>&1

while true; do
    inotifyd "$TRAMPOLINE" "$CONFIG_DIR:cwenmd" >> "$LOG" 2>&1 &
    IPID=$!
    echo "$IPID" > "$INOTIFY_PIDFILE"
    log "inotifyd started pid=$IPID"

    # inotifyd only exits on unwatchable/overflow; if it dies, restart after a short pause
    wait "$IPID"
    rc=$?
    log "inotifyd exited rc=$rc, restarting in 2s"
    sleep 2
done
